# Chapter 1 exercise: first steps

print("Hello, world!")
# TODO 1: Print a greeting of your own.

# TODO 2: Create variables for your name, a hobby, and a Python learning goal.

# TODO 3: Print a sentence that uses those variables.

# TODO 4: Add a comment about something you would like to build with Python.
