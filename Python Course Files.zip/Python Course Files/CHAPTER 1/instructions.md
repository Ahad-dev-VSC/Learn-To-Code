# Chapter 1: First steps

## What you will learn

Python runs instructions from top to bottom. `print()` displays information,
comments are notes for people, and variables give names to values.

```python
print("Hello, world!")
name = "Sam"
print("Hello,", name)
```

Text goes inside quotes. A line beginning with `#` is a comment and Python
ignores it. Variable names can contain letters, numbers, and underscores, but
cannot start with a number. Names are case-sensitive (`name` and `Name` differ).

## Try it

Open `Ex-1.py` and complete the TODOs:

1. Print a greeting of your own.
2. Make variables for your name, a hobby, and a goal for learning Python.
3. Print a sentence that uses each variable.
4. Add a comment describing what you want to build or do with Python.
5. Change one value and run the file again.

Use descriptive variable names such as `favorite_food`, not unclear names such
as `x`.

## Checkpoint

Can you explain what `print()` does, what a variable stores, and why text needs
quotes? Run the file and make sure it completes without an error.