# Chapter 10 exercise: errors and debugging

# TODO 1: Convert user input to an integer and handle ValueError.

# TODO 2: Divide two user-provided numbers and handle division by zero.

# TODO 3: Write a function that raises ValueError for a negative age.

# TODO 4: Add a finally block that prints a closing message.
