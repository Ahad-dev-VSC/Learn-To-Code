# Chapter 10: Errors and debugging

## What you will learn

Errors are a normal part of programming. Read the traceback: it points to the
line that failed and names the error. Common examples include `SyntaxError`
(invalid Python syntax), `NameError` (unknown name), `TypeError` (wrong kind
of value), and `ValueError` (right kind of value, invalid content).

Use `try` and `except` to handle an expected problem, such as invalid user
input. Catch the specific error you expect instead of hiding every possible
error. An `else` block runs if no exception occurred; `finally` runs whether
or not an error occurred.

```python
try:
    age = int(input("Age: "))
except ValueError:
    print("Please enter a whole number.")
else:
    print(f"Next year you will be {age + 1}.")
```

## Try it

Complete `Ex-10.py`:

1. Ask for a whole number and handle non-numeric input with `ValueError`.
2. Ask for two numbers and handle division by zero.
3. Write a function that rejects a negative age with a clear `ValueError`.
4. Add a `finally` block that prints a short closing message.
5. Deliberately create a small error, read its traceback, and fix it.

## Checkpoint

Do not use a bare `except:` to make errors disappear. Can you name the error
raised when converting `"hello"` with `int()`?
