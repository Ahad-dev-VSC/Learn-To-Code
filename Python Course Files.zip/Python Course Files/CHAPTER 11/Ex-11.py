# Chapter 11 exercise: reading and writing files

# Practice file: my_notes.txt

# TODO 1: Ask for a note and save it to my_notes.txt using UTF-8 encoding.

# TODO 2: Read the note back and print it.

# TODO 3: Append a second note without replacing the first.

# TODO 4: Print the file line by line with line numbers.

# TODO 5: Handle FileNotFoundError when reading a missing file.
