# Chapter 11: Reading and writing files

## What you will learn

Use `open()` with a `with` statement so a file is closed automatically. Text
files can be opened in read mode (`"r"`), write mode (`"w"`), or append mode
(`"a"`). Write mode replaces existing contents, so use it carefully.

```python
with open("notes.txt", "w", encoding="utf-8") as file:
    file.write("My first note\n")

with open("notes.txt", "r", encoding="utf-8") as file:
    contents = file.read()
print(contents)
```

Relative file paths are resolved from the program's current working directory,
which may not be the same as the directory containing the script. Begin with a
small test file you create yourself.

## Try it

Complete `Ex-11.py`:

1. Ask the user for a short note and save it to `my_notes.txt`.
2. Read the note back and print it.
3. Append a second note without replacing the first.
4. Read the file line by line and number the lines.
5. Handle a missing file with `FileNotFoundError`.

The exercise writes only the practice file `my_notes.txt` in the current
working directory. Do not test with important files.

## Checkpoint

Explain the difference between `"w"` and `"a"`. Why is `with open(...)` safer
than leaving an opened file around?
