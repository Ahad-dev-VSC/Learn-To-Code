# Chapter 12 exercise: classes and objects

# TODO 1: Define a Book class with title and author attributes.

# TODO 2: Add a method that describes the book.

# TODO 3: Create two books and print their descriptions.

# TODO 4: Define a BankAccount class with an owner and balance.

# TODO 5: Add deposit and safe-withdraw methods, then try them out.
