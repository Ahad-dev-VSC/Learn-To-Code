# Chapter 12: Classes and objects

## What you will learn

A class describes a kind of object. An object stores its own data in
attributes and can use methods defined by its class. `__init__` runs when a
new object is made; `self` refers to that object.

```python
class Dog:
    def __init__(self, name):
        self.name = name

    def speak(self):
        return f"{self.name} says woof!"

pet = Dog("Milo")
print(pet.speak())
```

Use a class when related data and behavior belong together. For a small,
one-off task, a function or dictionary may be simpler.

## Try it

Complete `Ex-12.py`:

1. Create a `Book` class with `title` and `author` attributes.
2. Add a method that returns a readable description of the book.
3. Create two books and print both descriptions.
4. Create a `BankAccount` class with an owner and starting balance.
5. Add deposit and withdraw methods. Do not allow a withdrawal larger than
   the balance; explain your choice to the user.

## Checkpoint

Can you distinguish a class from an object? What does `self` refer to when
you call a method?
