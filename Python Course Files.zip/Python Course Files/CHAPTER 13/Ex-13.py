# Chapter 13 exercise: standard library and JSON

# TODO 1: Display today's date with datetime.

# TODO 2: Find the mean and median of a list with statistics.

# TODO 3: Convert a dictionary to a JSON string with json.dumps().

# TODO 4: Convert it back with json.loads() and print one value.

# TODO 5: Save and load JSON using the practice file settings.json.
