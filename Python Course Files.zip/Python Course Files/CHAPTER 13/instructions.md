# Chapter 13: Standard library and JSON

## What you will learn

Python includes useful modules for common jobs. `datetime` works with dates
and times; `statistics` calculates values such as a mean; `json` converts
between Python data and JSON text, a common format for storing and exchanging
structured information.

```python
import json

settings = {"theme": "light", "notifications": True}
text = json.dumps(settings)
restored = json.loads(text)
print(restored["theme"])
```

JSON supports objects, arrays, strings, numbers, booleans, and `null`. In
Python, the matching values include dictionaries, lists, strings, numbers,
`True`/`False`, and `None`.

## Try it

Complete `Ex-13.py`:

1. Use `datetime` to display today's date.
2. Use `statistics` to calculate the mean and median of a list of numbers.
3. Convert a dictionary to a JSON string and print it.
4. Convert the JSON string back to Python data and read one value.
5. Save JSON to `settings.json`, then read it back. Use a practice file only.

## Checkpoint

What is the difference between `json.dumps()` and `json.loads()`? (For files,
the corresponding functions are `json.dump()` and `json.load()`.)
