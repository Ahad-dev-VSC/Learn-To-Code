# Chapter 14 final project: personal task tracker

# Suggested task shape:
# {"description": "Practice Python", "complete": False}

# TODO 1: Write a function to display tasks with their numbers and status.

# TODO 2: Write a function to add a task.

# TODO 3: Write a function to mark a task complete.

# TODO 4: Use a loop to show a menu and handle the user's choice.

# TODO 5: Load and save tasks in a practice JSON file named tasks.json.

# TODO 6: Add assert checks for helper functions that do not need input().
