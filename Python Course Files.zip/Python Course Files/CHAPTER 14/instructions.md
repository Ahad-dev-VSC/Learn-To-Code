# Chapter 14: Testing and final project

## What you will learn

Testing checks that your code behaves as expected. A simple test can use an
`assert` statement:

```python
def double(number):
    return number * 2

assert double(3) == 6
```

When an assertion fails, Python raises `AssertionError`. Test typical inputs,
boundary values, and invalid input where it applies. Keep tests repeatable and
avoid depending on manual input where possible.

## Final project: personal task tracker

Build a small command-line task tracker in `Ex-14.py`. Use the skills from
earlier chapters:

1. Store tasks in a list of dictionaries. Each task should have a description
   and a completion status.
2. Put repeated work into functions: display tasks, add a task, and mark a
   task complete.
3. Show a menu in a loop and let the user choose an action.
4. Handle invalid menu choices and invalid task numbers without crashing.
5. Save tasks to a JSON file when the program exits, and load them when it
   starts. Use a new practice file such as `tasks.json`.
6. Add at least three `assert` checks for any helper functions that can be
   tested without user input.

## Stretch goals

- Add a due date to each task.
- Let the user remove a task.
- Add a search option.
- Split the project into multiple Python files.

## Completion checklist

- The program starts and exits cleanly.
- Tasks can be added, displayed, and marked complete.
- Data is still present after restarting the program.
- Incorrect input produces a helpful message.
- You can explain how your functions, list, dictionaries, loop, and JSON code
  work.

Congratulations on completing the course. Keep practicing by making a small
program for a problem you encounter in everyday life.
