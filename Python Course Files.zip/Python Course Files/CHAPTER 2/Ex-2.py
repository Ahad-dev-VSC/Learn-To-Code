# Chapter 2 exercise: values, types, and arithmetic

# TODO 1: Create an int, float, str, and bool value.

# TODO 2: Print each value and its type.

# TODO 3: Calculate and print the area of a rectangle.

# TODO 4: Convert a number of minutes into hours and remaining minutes.

# TODO 5: Compare / and // with two numbers. Write your observation as a comment.
