# Chapter 2: Values, types, and arithmetic

## What you will learn

Python has several common built-in types:

- `str` for text, such as `"blue"`
- `int` for whole numbers, such as `12`
- `float` for decimal numbers, such as `3.5`
- `bool` for `True` or `False`

Use `type(value)` to inspect a value's type. Arithmetic uses `+`, `-`, `*`,
`/`, `//` (whole-number division), `%` (remainder), and `**` (power). Python
follows the usual order of operations; parentheses make the order clear.

```python
total = 3 * (4 + 2)
print(total)
print(type(total))
```

## Try it

Complete `Ex-2.py`:

1. Create an integer, a decimal, a text value, and a Boolean.
2. Print each value and its type.
3. Calculate the area of a rectangle using width and height variables.
4. Given a number of minutes, calculate whole hours and remaining minutes
   using `//` and `%`.
5. Try division and floor division on the same pair of numbers. Explain the
   difference in a comment.

## Checkpoint

Before moving on, make sure you can identify a value's type and predict the
result of `17 // 5` and `17 % 5`.
