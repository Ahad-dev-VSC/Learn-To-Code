# Chapter 3 exercise: input and formatted output

# TODO 1: Ask for a name and print a friendly greeting.

# TODO 2: Ask for two numbers, convert them, and print their sum.

# TODO 3: Ask for a price and quantity, then display the total to 2 decimals.

# TODO 4: Convert a user-provided Celsius temperature to Fahrenheit.
