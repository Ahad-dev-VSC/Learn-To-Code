# Chapter 3: Input and formatted output

## What you will learn

`input()` pauses the program and returns what the user typed as a string.
Convert that string when you need a number: `int("8")` or `float("2.5")`.

An f-string starts with `f` and places expressions inside braces:

```python
name = "Rae"
score = 7
print(f"{name} scored {score} points.")
```

You can use formatting inside the braces, for example `f"{price:.2f}"` to show
two digits after the decimal point.

## Try it

Complete `Ex-3.py`:

1. Ask for the user's name and greet them.
2. Ask for two numbers, convert them, and print their sum.
3. Ask for a price and quantity; print the total to two decimal places.
4. Ask for a temperature in Celsius and display its Fahrenheit equivalent
   (`C * 9 / 5 + 32`).
5. Try entering text where a number is expected. Note the error; Chapter 10
   will show you how to handle it.

## Checkpoint

Remember that `input()` gives you text, even when the user types digits. Convert
it before doing arithmetic.
