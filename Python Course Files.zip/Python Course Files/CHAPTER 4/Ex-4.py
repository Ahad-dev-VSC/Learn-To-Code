# Chapter 4 exercise: decisions

# TODO 1: Ask for a number and classify it as positive, negative, or zero.

# TODO 2: Check whether an age is at least 18.

# TODO 3: Convert a score from 0 to 100 into a letter grade.

# TODO 4: Check whether a year is a leap year.
