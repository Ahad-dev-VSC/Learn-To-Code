# Chapter 4: Making decisions with conditions

## What you will learn

Use `if`, `elif`, and `else` to choose which code runs. Comparisons include
`==`, `!=`, `<`, `<=`, `>`, and `>=`. Use `and`, `or`, and `not` to combine
conditions. A single `=` assigns a value; `==` compares values.

```python
temperature = 22
if temperature > 25:
    print("Warm")
elif temperature >= 15:
    print("Comfortable")
else:
    print("Cool")
```

Indentation is part of Python's syntax: the statements belonging to a branch
must be indented consistently.

## Try it

Complete `Ex-4.py`:

1. Ask for a number and say whether it is positive, negative, or zero.
2. Ask for an age and report whether the person is at least 18.
3. Ask for a score from 0 to 100 and assign a letter grade using your chosen
   grade boundaries.
4. Ask for a year and determine whether it is a leap year: divisible by 4,
   except century years must also be divisible by 400.
5. Test values on the boundaries of your conditions.

## Checkpoint

Can you explain why the leap-year rule needs both `and` and `or`? Use
parentheses to make a combined condition easy to read.
