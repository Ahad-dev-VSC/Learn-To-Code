# Chapter 5 exercise: loops

# TODO 1: Print the numbers 1 through 10 with a for loop.

# TODO 2: Print the even numbers from 2 through 20.

# TODO 3: Calculate the sum from 1 through 100.

# TODO 4: Repeat a password question with a while loop until it matches.

# TODO 5: Ask for a number and print its multiplication table.
