# Chapter 5: Repeating work with loops

## What you will learn

A `for` loop visits each item in a sequence. `range(stop)` produces numbers
from zero up to, but not including, `stop`. A `while` loop repeats as long as
its condition is true.

```python
for number in range(1, 4):
    print(number)

count = 3
while count > 0:
    print(count)
    count -= 1
```

Be sure a `while` loop changes something that will eventually make its
condition false. Otherwise it may never stop. `break` exits a loop; `continue`
skips to its next iteration.

## Try it

Complete `Ex-5.py`:

1. Print the numbers 1 through 10 with a `for` loop.
2. Print the even numbers between 2 and 20.
3. Calculate the sum of the numbers from 1 through 100.
4. Use a `while` loop to keep asking for a password until the answer matches
   a value you chose. Do not use a real password.
5. Make a multiplication table for a number entered by the user.

## Checkpoint

Try explaining how many times `range(2, 8)` runs and why the endpoint is not
included.
