# Chapter 6 exercise: lists and tuples

# TODO 1: Create a list of five favorite foods; print the first and last.

# TODO 2: Add and remove an item, then print the list.

# TODO 3: Print a slice containing the middle three items.

# TODO 4: Ask for three numbers; print their minimum, maximum, and average.

# TODO 5: Create a 2D point tuple and print its coordinates.
