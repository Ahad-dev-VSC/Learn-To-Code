# Chapter 6: Lists and tuples

## What you will learn

A list stores an ordered, changeable collection. Lists use square brackets;
indexes start at zero. Negative indexes count from the end. Common operations
include `append`, `insert`, `remove`, `pop`, `sort`, and `len`.

```python
colors = ["red", "green", "blue"]
colors.append("gold")
print(colors[0])
print(colors[1:3])
```

A tuple is an ordered collection that you do not normally change after
creating it: `point = (4, 9)`. Slices use a start index and an end index that
is not included.

## Try it

Complete `Ex-6.py`:

1. Make a list of five favorite foods and print the first and last.
2. Add an item, remove an item, and print the updated list.
3. Print a slice containing the middle three items.
4. Ask the user for three numbers; store them in a list and print the minimum,
   maximum, and average.
5. Create a tuple representing a 2D point and print each coordinate.

## Checkpoint

Can you describe the difference between a list and a tuple? What error might
you get when indexing beyond a list's length?
