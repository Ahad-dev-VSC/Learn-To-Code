# Chapter 7 exercise: dictionaries and sets

# TODO 1: Describe a book in a dictionary with at least three fields.

# TODO 2: Read, update, and add dictionary values.

# TODO 3: Loop through the dictionary and print its fields.

# TODO 4: Count words in a sentence using a dictionary.

# TODO 5: Compare two sets of activities.
