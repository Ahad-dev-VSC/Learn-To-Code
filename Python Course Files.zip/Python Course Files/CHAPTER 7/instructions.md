# Chapter 7: Dictionaries and sets

## What you will learn

A dictionary maps unique keys to values. Use square brackets to read or
update a key, and `get()` when a key may not exist. You can loop through
`.items()` to get each key-value pair.

```python
person = {"name": "Kai", "city": "Oslo"}
person["city"] = "Lima"
print(person.get("country", "Not provided"))
```

A set stores unique items without a guaranteed order. Use it to remove
duplicates or compare groups with operations such as `|` (union), `&`
(intersection), and `-` (difference).

## Try it

Complete `Ex-7.py`:

1. Create a dictionary describing a book with at least three fields.
2. Read a field, update a field, and add another one.
3. Loop through the dictionary and print each field and value.
4. Count how many times each word appears in a short sentence using a
   dictionary.
5. Make two sets of favorite activities; display shared and distinct items.

## Checkpoint

Use `.get()` when a key might be missing. What happens to duplicate values
when they are added to a set?
