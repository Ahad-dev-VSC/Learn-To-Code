# Chapter 8 exercise: functions

# TODO 1: Define greet(name) and return a greeting.

# TODO 2: Define rectangle_area(width, height).

# TODO 3: Define is_even(number).

# TODO 4: Define calculate_tip(total, percent=15).

# TODO 5: Call each function with multiple inputs and print the results.
