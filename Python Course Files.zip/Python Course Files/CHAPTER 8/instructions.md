# Chapter 8: Functions

## What you will learn

Functions package reusable instructions. Define one with `def`, give it
parameters, and return a result with `return`.

```python
def greet(name):
    return f"Hello, {name}!"

message = greet("Ari")
print(message)
```

Parameters are names in the function definition; arguments are the values
passed when calling it. A default parameter value can make an argument
optional. Keep functions focused on one job.

## Try it

Complete `Ex-8.py`:

1. Write `greet(name)` that returns a greeting.
2. Write `rectangle_area(width, height)` that returns an area.
3. Write `is_even(number)` that returns `True` or `False`.
4. Write `calculate_tip(total, percent=15)` that returns the tip amount.
5. Call each function with several inputs and print its result.

## Checkpoint

Make sure your functions return values rather than only printing them. What is
the difference between a parameter and an argument?
