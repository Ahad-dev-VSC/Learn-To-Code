# Chapter 9 exercise: strings and imports

# TODO 1: Clean up a user's full name and display it in title case.

# TODO 2: Count the words in a sentence using split().

# TODO 3: Replace a word and print the new sentence.

# TODO 4: Import math and calculate a square root.

# TODO 5: Import random and choose an item from a list.
