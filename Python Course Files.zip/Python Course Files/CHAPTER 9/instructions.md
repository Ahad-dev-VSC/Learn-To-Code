# Chapter 9: Strings and imports

## What you will learn

Strings are sequences of characters. You can index or slice them, join them
with `+`, repeat them with `*`, and use helpful methods such as `lower()`,
`upper()`, `strip()`, `replace()`, and `split()`. Strings are immutable:
methods return new strings instead of changing the original.

Python's standard library provides modules. Import a module or selected names
to use its features:

```python
import math
print(math.sqrt(81))

from random import choice
print(choice(["tea", "coffee"]))
```

Avoid naming your files after standard modules (for example, do not name a
file `random.py`), because Python may import your file instead.

## Try it

Complete `Ex-9.py`:

1. Ask for a full name, remove extra spaces, and display it in title case.
2. Count the words in a sentence using `split()`.
3. Replace one word in a sentence and display the new sentence.
4. Use `math` to calculate the square root of a number.
5. Use `random` to choose an item from a short list.

## Checkpoint

Try a string method without assigning its result, then print the original
string. Notice that the original does not change.
