@echo off
cd /d "%~dp0"
if exist "%~dp0.venv\Scripts\python.exe" (
    start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0exercise_app.py"
) else (
    start "" pythonw "%~dp0exercise_app.py"
)
