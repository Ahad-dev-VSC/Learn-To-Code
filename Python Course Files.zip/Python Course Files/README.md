# Python Course

A hands-on course for learning Python from the beginning. Each chapter has:

- `instructions.md` — explanations, practice tasks, and a checkpoint.
- `Ex-N.py` — your workspace for writing and running the exercises.

Work through the chapters in order. Try each task before looking anything up, and
change the examples to see what happens. The exercise files are intentionally
unfinished: the goal is for you to write the code.

## Getting started

1. Install Python 3 from [python.org](https://www.python.org/downloads/) if it
   is not already installed. On Windows, select the option to add Python to PATH
   during installation.
2. Open a terminal in this course folder and check your installation:

   ```text
   python --version
   ```

   If that command is not recognized on Windows, try `py --version`.
3. Read Chapter 1, then run its exercise file:

   ```text
   python "CHAPTER 1/Ex-1.py"
   ```

   On Windows, `py "CHAPTER 1\Ex-1.py"` is also an option.
4. Save often. Run your exercise file again whenever you want to test your
   changes.

## Course map

1. First steps: output, comments, and variables
2. Values, types, and arithmetic
3. Input and formatted output
4. Making decisions with conditions
5. Repeating work with loops
6. Lists and tuples
7. Dictionaries and sets
8. Functions
9. Strings and imports
10. Errors and debugging
11. Reading and writing files
12. Classes and objects
13. Useful standard-library tools and JSON
14. Testing and a final project

## How to get the most from the course

- Type the code yourself instead of only reading it.
- Read error messages from the bottom up; the last line usually names the
  problem.
- Keep your own notes and add extra experiments to the exercise file.
- Complete each checkpoint before moving on. There is no need to rush.

All lessons use Python's standard library; no extra packages are required.

## Exercise checker application

To open the desktop application, double-click:

```text
Launch Exercise Checker.bat
```

You can also launch it from the terminal:

```pwsh
python exercise_app.py
```

The application lets you:

- Choose a chapter from 1 to 14
- Open a specific Python exercise file
- Check the exercise with one click
- Read a green success result or numbered step-by-step fixes

## Command-line checker

The original command-line checker remains available:

```pwsh
python check_exercises.py
```

Enter a chapter number (for example, `2`) or an exercise path when prompted.
You can also pass the selection directly:

```pwsh
python check_exercises.py 2
python check_exercises.py "CHAPTER 2\Ex-2.py"
```

A correct exercise prints `Correct`. If it is incomplete or incorrect, the
checker prints numbered steps describing what to fix.
