import ast
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def list_of_calls(tree):
    calls = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                calls.append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                calls.append(node.func.attr)
    return calls


def assigned_names(tree):
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            names.add(node.id)
    return names


def method_names(tree):
    result = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            result.add(node.func.attr)
    return result


def imports(tree):
    modules = set()
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name.split('.')[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                modules.add(node.module.split('.')[0])
            names.update(alias.name for alias in node.names)
    return modules, names


def has_binop(tree, operator_type):
    return any(isinstance(node.op, operator_type) for node in ast.walk(tree) if isinstance(node, ast.BinOp))


def exception_names(tree):
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            if isinstance(node.type, ast.Name):
                names.add(node.type.id)
            elif isinstance(node.type, ast.Attribute):
                names.add(node.type.attr)
    return names


def check_chapter_one(tree, text):
    calls = list_of_calls(tree)
    names = assigned_names(tree)
    required = ["name", "hobby", "goal"]
    missing = [item for item in required if item not in names]
    issues = []
    if calls.count("print") < 3:
        issues.append("Add at least three print() calls: a greeting and sentences using your three variables.")
    if missing:
        issues.append("Create variables named " + ", ".join(missing) + " for your name, hobby, and goal.")
    if not any(line.strip().startswith("#") for line in text.splitlines()):
        issues.append("Add a comment beginning with # that describes what you want to build.")
    return issues


def check_chapter_two(tree, text):
    calls = list_of_calls(tree)
    names = assigned_names(tree)
    issues = []
    if not any(isinstance(node, ast.Constant) and isinstance(node.value, int) and not isinstance(node.value, bool) for node in ast.walk(tree)):
        issues.append("Create an integer value, for example: whole_number = 12")
    if not any(isinstance(node, ast.Constant) and isinstance(node.value, float) for node in ast.walk(tree)):
        issues.append("Create a decimal (float) value, for example: decimal_number = 3.5")
    if not any(isinstance(node, ast.Constant) and isinstance(node.value, str) for node in ast.walk(tree)):
        issues.append("Create a text (str) value, for example: text_value = \"Python\"")
    if not any(isinstance(node, ast.Constant) and isinstance(node.value, bool) for node in ast.walk(tree)):
        issues.append("Create a Boolean value using True or False, for example: is_learning = True")
    if calls.count("print") < 4:
        issues.append("Print each value and its type.")
    if calls.count("type") < 4:
        issues.append("Use type(value) when printing the type of each of the four values.")
    if not {"width", "height", "area"}.issubset(names):
        issues.append("Create width and height variables, then store width * height in area.")
    if not {"hours", "minutes"}.issubset(names):
        issues.append("Create hours and minutes variables for the minute conversion.")
    if not has_binop(tree, ast.FloorDiv):
        issues.append("Use // to calculate whole hours.")
    if not has_binop(tree, ast.Mod):
        issues.append("Use % to calculate the remaining minutes.")
    if not has_binop(tree, ast.Div):
        issues.append("Use / to compare normal division with floor division.")
    if not any("/" in line or "//" in line for line in text.splitlines() if line.strip().startswith("#")):
        issues.append("Add a comment explaining the difference between / and //.")
    return issues


def check_chapter_three(tree):
    calls = list_of_calls(tree)
    issues = []
    if calls.count("input") < 4:
        issues.append("Ask for at least four pieces of input: name, two numbers, price, quantity, and temperature.")
    if calls.count("int") < 2:
        issues.append("Convert numeric input with int() before doing arithmetic.")
    if calls.count("float") < 2:
        issues.append("Convert price and quantity input with float() or int().")
    if not any(isinstance(node, ast.JoinedStr) for node in ast.walk(tree)):
        issues.append("Use an f-string to format at least one displayed answer.")
    if not any(isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add) for node in ast.walk(tree)):
        issues.append("Calculate the sum of the two converted numbers with +.")
    return issues


def check_chapter_four(tree):
    calls = list_of_calls(tree)
    if_count = sum(isinstance(node, ast.If) for node in ast.walk(tree))
    issues = []
    if calls.count("input") < 4:
        issues.append("Ask for a number, an age, a score, and a year using input().")
    if if_count < 4:
        issues.append("Use if/elif/else decisions for the number, age, grade, and leap-year tasks.")
    if not any(isinstance(node, ast.Compare) for node in ast.walk(tree)):
        issues.append("Add comparison operators such as <, >, >=, ==, or !=.")
    if not has_binop(tree, ast.Mult) and not any(isinstance(node, ast.Mod) for node in ast.walk(tree)):
        issues.append("Use modulo % and divisibility checks in the leap-year condition.")
    return issues


def check_chapter_five(tree):
    calls = list_of_calls(tree)
    issues = []
    fors = sum(isinstance(node, ast.For) for node in ast.walk(tree))
    whiles = sum(isinstance(node, ast.While) for node in ast.walk(tree))
    if fors < 2:
        issues.append("Use at least two for loops: one for 1–10 and one for even numbers.")
    if whiles < 1:
        issues.append("Use a while loop to keep asking for the password.")
    if calls.count("range") < 3:
        issues.append("Use range() for the number, even-number, and multiplication-table loops.")
    if not has_binop(tree, ast.Add):
        issues.append("Use + to add values together when calculating the sum from 1 through 100.")
    if calls.count("input") < 2:
        issues.append("Use input() for the password and multiplication-table number.")
    return issues


def check_chapter_six(tree):
    names = assigned_names(tree)
    methods = method_names(tree)
    calls = list_of_calls(tree)
    issues = []
    if not any(isinstance(node, (ast.List, ast.ListComp)) for node in ast.walk(tree)):
        issues.append("Create a list of five foods using square brackets.")
    if not {"append", "remove"}.issubset(methods):
        issues.append("Use append() to add an item and remove() to remove an item.")
    if not any(isinstance(node, ast.Slice) for node in ast.walk(tree)):
        issues.append("Use list slicing, such as foods[1:4], for the middle three items.")
    if not {"min", "max"}.issubset(set(calls)):
        issues.append("Calculate the minimum and maximum with min() and max().")
    if not any(isinstance(node, ast.Tuple) for node in ast.walk(tree)):
        issues.append("Create a tuple using parentheses, for example: point = (4, 9).")
    if calls.count("input") < 3:
        issues.append("Ask for three numbers using input() and store them in a list.")
    return issues


def check_chapter_seven(tree):
    calls = list_of_calls(tree)
    methods = method_names(tree)
    issues = []
    if not any(isinstance(node, ast.Dict) for node in ast.walk(tree)):
        issues.append("Create a dictionary with book fields using curly braces and key-value pairs.")
    if not any(isinstance(node, ast.Set) or isinstance(node, ast.Call) and getattr(node.func, 'id', None) == 'set' for node in ast.walk(tree)):
        issues.append("Create two sets using set() or curly braces.")
    if "items" not in methods:
        issues.append("Use .items() to loop through the dictionary's fields and values.")
    if "get" not in methods:
        issues.append("Use .get() at least once when reading a possible dictionary value.")
    if not any(isinstance(node, ast.BinOp) and isinstance(node.op, (ast.BitOr, ast.BitAnd, ast.BitSub)) for node in ast.walk(tree)):
        issues.append("Compare the two sets with union |, intersection &, or difference -. ")
    if not any(isinstance(node, ast.Assign) for node in ast.walk(tree)):
        issues.append("Add word-count assignments to a dictionary.")
    return issues


def check_chapter_eight(tree):
    calls = list_of_calls(tree)
    functions = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    issues = []
    for name in ("greet", "rectangle_area", "is_even", "calculate_tip"):
        if name not in functions:
            issues.append(f"Define the function {name}(...).")
    if not any(isinstance(node, ast.Return) for node in ast.walk(tree)):
        issues.append("Use return in each function; the functions should return values rather than print them.")
    if sum(name in calls for name in ("greet", "rectangle_area", "is_even", "calculate_tip")) < 4:
        issues.append("Call each of the four functions and print their returned results.")
    return issues


def check_chapter_nine(tree):
    calls = list_of_calls(tree)
    methods = method_names(tree)
    modules, names = imports(tree)
    issues = []
    if calls.count("input") < 2:
        issues.append("Ask for a full name and a sentence using input().")
    if not {"strip", "title", "split", "replace"}.issubset(methods):
        issues.append("Use string methods including strip(), title(), split(), and replace().")
    if "math" not in modules:
        issues.append("Import math and use math.sqrt().")
    if "random" not in modules:
        issues.append("Import random and use random.choice().")
    return issues


def check_chapter_ten(tree):
    calls = list_of_calls(tree)
    exceptions = exception_names(tree)
    issues = []
    if calls.count("int") < 1:
        issues.append("Convert user input to an integer using int().")
    if not {"ValueError", "ZeroDivisionError"}.issubset(exceptions):
        issues.append("Add except ValueError and except ZeroDivisionError handlers.")
    if not any(isinstance(node, ast.Try) and node.finalbody for node in ast.walk(tree)):
        issues.append("Add a finally block that prints a closing message.")
    functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    if not any("age" in {arg.arg for arg in function.args.args} for function in functions):
        issues.append("Define a function that accepts age and raises ValueError for negative ages.")
    return issues


def check_chapter_eleven(tree):
    calls = list_of_calls(tree)
    exceptions = exception_names(tree)
    issues = []
    if not any(isinstance(node, ast.With) for node in ast.walk(tree)):
        issues.append("Use a with open(...) statement to read and write safely.")
    if calls.count("open") < 2:
        issues.append("Use open() for writing and reading the practice file.")
    modes = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "open" and len(node.args) > 1:
            if isinstance(node.args[1], ast.Constant) and isinstance(node.args[1].value, str):
                modes.add(node.args[1].value)
    if not {"w", "r", "a"}.issubset(modes):
        issues.append("Open my_notes.txt in write ('w'), read ('r'), and append ('a') modes.")
    if "FileNotFoundError" not in exceptions:
        issues.append("Handle FileNotFoundError when attempting to read a missing file.")
    return issues


def check_chapter_twelve(tree):
    classes = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)}
    issues = []
    for name in ("Book", "BankAccount"):
        if name not in classes:
            issues.append(f"Define a {name} class.")
    if "Book" in classes:
        methods = {node.name for node in ast.walk(classes["Book"]) if isinstance(node, ast.FunctionDef)}
        if "__init__" not in methods:
            issues.append("Add Book.__init__(self, title, author).")
        if not methods - {"__init__"}:
            issues.append("Add a method to Book that returns a readable description.")
    if "BankAccount" in classes:
        methods = {node.name for node in ast.walk(classes["BankAccount"]) if isinstance(node, ast.FunctionDef)}
        if not {"__init__", "deposit", "withdraw"}.issubset(methods):
            issues.append("Give BankAccount __init__, deposit, and withdraw methods.")
    return issues


def check_chapter_thirteen(tree):
    calls = list_of_calls(tree)
    modules, names = imports(tree)
    issues = []
    if not {"datetime", "statistics", "json"}.issubset(modules):
        issues.append("Import datetime, statistics, and json.")
    if not {"mean", "median"}.issubset(set(calls)):
        issues.append("Use statistics.mean() and statistics.median().")
    if not {"dumps", "loads"}.issubset(set(calls)):
        issues.append("Use json.dumps() and json.loads().")
    if not {"dump", "load"}.issubset(set(calls)):
        issues.append("Use json.dump() and json.load() to save and read settings.json.")
    return issues


def check_chapter_fourteen(tree):
    calls = list_of_calls(tree)
    functions = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    modules, names = imports(tree)
    issues = []
    if not {"display_tasks", "add_task", "mark_complete"}.issubset(functions):
        issues.append("Define display_tasks, add_task, and mark_complete helper functions.")
    if not any(isinstance(node, ast.While) for node in ast.walk(tree)):
        issues.append("Use a while loop to keep the task tracker menu running.")
    if not any(isinstance(node, ast.Dict) for node in ast.walk(tree)):
        issues.append("Represent tasks as dictionaries with description and complete fields.")
    if "json" not in modules:
        issues.append("Import json for loading and saving tasks.json.")
    if not {"dump", "load"}.issubset(set(calls)):
        issues.append("Use json.dump() and json.load() for tasks.json.")
    asserts = sum(isinstance(node, ast.Assert) for node in ast.walk(tree))
    if asserts < 3:
        issues.append("Add at least three assert checks for helper functions that do not need input().")
    return issues


CHECKERS = {
    1: check_chapter_one,
    2: check_chapter_two,
    3: check_chapter_three,
    4: check_chapter_four,
    5: check_chapter_five,
    6: check_chapter_six,
    7: check_chapter_seven,
    8: check_chapter_eight,
    9: check_chapter_nine,
    10: check_chapter_ten,
    11: check_chapter_eleven,
    12: check_chapter_twelve,
    13: check_chapter_thirteen,
    14: check_chapter_fourteen,
}


def resolve_file(selection):
    selection = selection.strip().strip('"\'')
    if not selection:
        return None

    direct = Path(selection)
    if not direct.is_absolute():
        direct = ROOT / direct
    if direct.is_file():
        return direct.resolve()

    digits = ''.join(ch for ch in selection if ch.isdigit())
    if digits:
        chapter = int(digits)
        candidate = ROOT / f"CHAPTER {chapter}" / f"Ex-{chapter}.py"
        if candidate.is_file():
            return candidate.resolve()

    return None


def ask_for_selection():
    print("Python exercise checker")
    print("Available exercises: 1 to 14")
    print("Enter a chapter number (for example, 2) or a file path.")
    try:
        return input("Which Python file should I check? ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled. Run the checker again and enter a chapter number.")
        raise SystemExit(130)


def check_exercise(selection):
    """Validate an exercise and return a structured result."""
    path = resolve_file(selection)

    if path is None:
        return {
            "status": "Not checked",
            "path": None,
            "issues": [
                "Enter a chapter number from 1 to 14, such as 2.",
                "Or enter a path like CHAPTER 2\\Ex-2.py.",
            ],
        }

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return {
            "status": "Not checked",
            "path": path,
            "issues": ["The selected file is not readable as UTF-8 text."],
        }

    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as error:
        return {
            "status": "Not correct",
            "path": path,
            "issues": [
                f"Fix the syntax error on line {error.lineno}: {error.msg}",
                "Check the line for missing quotes, brackets, parentheses, or a colon.",
                "Save the file, then run the checker again.",
            ],
        }

    chapter_match = next((number for number in range(1, 15)
                          if path.name.lower() == f"ex-{number}.py"), None)

    if chapter_match is None:
        return {
            "status": "Not checked",
            "path": path,
            "issues": ["Select an exercise file named Ex-N.py from Chapter 1 through Chapter 14."],
        }

    checker = CHECKERS[chapter_match]
    issues = checker(tree, text) if chapter_match in (1, 2) else checker(tree)

    todo_lines = [number for number, line in enumerate(text.splitlines(), 1)
                  if "TODO" in line.upper()]
    if todo_lines:
        issues.insert(
            0,
            "Unfinished TODO marker(s) remain on line(s) "
            + ", ".join(map(str, todo_lines))
            + ". Replace the TODO comments by writing the task code.",
        )

    issues = list(dict.fromkeys(issues))
    if issues:
        return {"status": "Not correct", "path": path, "issues": issues}
    return {
        "status": "Correct",
        "path": path,
        "issues": ["All checked requirements found. The exercise is ready."],
    }


def main():
    selection = sys.argv[1] if len(sys.argv) > 1 else ask_for_selection()
    result = check_exercise(selection)

    print(result["status"])
    if result["path"]:
        print(f"Exercise: {result['path'].relative_to(ROOT)}")
    if result["status"] != "Correct":
        print("Follow these steps:")
    for number, issue in enumerate(result["issues"], 1):
        print(f"  {number}. {issue}" if result["status"] != "Correct" else issue)

    return 0 if result["status"] == "Correct" else 1


if __name__ == "__main__":
    raise SystemExit(main())
