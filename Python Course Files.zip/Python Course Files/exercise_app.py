import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

from check_exercises import ROOT, check_exercise


COURSE_TITLES = {
    1: "First steps",
    2: "Values and arithmetic",
    3: "Input and formatted output",
    4: "Conditions",
    5: "Loops",
    6: "Lists and tuples",
    7: "Dictionaries and sets",
    8: "Functions",
    9: "Strings and imports",
    10: "Errors and debugging",
    11: "Reading and writing files",
    12: "Classes and objects",
    13: "Standard library and JSON",
    14: "Testing and final project",
}


class ExerciseApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Python Course Exercise Checker")
        self.geometry("1040x680")
        self.minsize("820", "560")
        self.selected_chapter = tk.IntVar(value=1)

        self.configure(padx=18, pady=18)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        header = ttk.Frame(self)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        ttk.Label(header, text="Python Course", font=("Segoe UI", 22, "bold")).pack(side="left")
        ttk.Label(header, text="Exercise Checker", font=("Segoe UI", 11)).pack(side="left", padx=(12, 0), pady=(8, 0))

        selector = ttk.Frame(self)
        selector.grid(row=1, column=0, sticky="ew")
        selector.columnconfigure(1, weight=1)

        ttk.Label(selector, text="Chapter", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 10))

        chapter_names = [f"Chapter {number}: {title}" for number, title in COURSE_TITLES.items()]
        self.chapter_combo = ttk.Combobox(selector, values=chapter_names, state="readonly")
        self.chapter_combo.current(0)
        self.chapter_combo.grid(row=0, column=1, sticky="ew")
        self.chapter_combo.bind("<<ComboboxSelected>>", self.chapter_changed)

        self.check_button = ttk.Button(selector, text="Check Exercise", command=self.check_selected)
        self.check_button.grid(row=0, column=2, padx=(10, 0), ipady=5)

        open_button = ttk.Button(selector, text="Open file…", command=self.choose_file)
        open_button.grid(row=0, column=3, padx=(8, 0), ipady=5)

        content = ttk.Frame(self)
        content.grid(row=2, column=0, sticky="nsew", pady=(14, 0))
        content.columnconfigure(0, weight=1)
        content.columnconfigure(1, weight=2)
        content.rowconfigure(0, weight=1)

        left = ttk.LabelFrame(content, text="Exercise", padding=12)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)

        ttk.Label(left, text="Instructions", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")
        self.instructions = tk.Text(left, wrap="word", height=20, padx=10, pady=10,
                                    font=("Segoe UI", 10), relief="flat")
        self.instructions.grid(row=1, column=0, sticky="nsew", pady=(8, 0))

        right = ttk.LabelFrame(content, text="Check result", padding=12)
        right.grid(row=0, column=1, sticky="nsew")
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)

        self.status_label = ttk.Label(right, text="Ready", font=("Segoe UI", 12, "bold"))
        self.status_label.grid(row=0, column=0, sticky="w")

        self.results = tk.Text(right, wrap="word", padx=14, pady=12,
                               font=("Consolas", 10), relief="flat")
        self.results.grid(row=1, column=0, sticky="nsew", pady=(8, 0))

        footer = ttk.Frame(self)
        footer.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        self.file_label = ttk.Label(footer, text="No file selected", foreground="#666666")
        self.file_label.pack(side="left")

        self.chapter_changed()

    def chapter_changed(self, _event=None):
        chapter = self.chapter_combo.current() + 1
        self.selected_chapter.set(chapter)
        path = ROOT / f"CHAPTER {chapter}" / f"Ex-{chapter}.py"
        self.file_label.configure(text=str(path.relative_to(ROOT)))

        instruction_path = ROOT / f"CHAPTER {chapter}" / "instructions.md"
        try:
            instructions = instruction_path.read_text(encoding="utf-8")
        except OSError:
            instructions = "Instructions could not be loaded."

        self.instructions.configure(state="normal")
        self.instructions.delete("1.0", "end")
        self.instructions.insert("1.0", instructions)
        self.instructions.configure(state="disabled")

        self.clear_result()

    def clear_result(self):
        self.status_label.configure(text="Ready", foreground="#333333")
        self.results.configure(state="normal")
        self.results.delete("1.0", "end")
        self.results.insert("1.0", "Choose a chapter and select “Check Exercise”.")
        self.results.configure(state="disabled")

    def choose_file(self):
        initial_dir = ROOT
        file_path = filedialog.askopenfilename(
            title="Choose a Python exercise",
            initialdir=initial_dir,
            filetypes=[("Python files", "*.py")],
        )
        if file_path:
            path = Path(file_path)
            try:
                relative = path.relative_to(ROOT)
                self.file_label.configure(text=str(relative))
            except ValueError:
                self.file_label.configure(text=str(path))

            try:
                chapter = int(path.stem.split("-")[-1])
                if 1 <= chapter <= 14:
                    self.chapter_combo.current(chapter - 1)
                    self.selected_chapter.set(chapter)
                    self.chapter_changed()
            except ValueError:
                pass

            self.check_exercise_path(str(path))

    def check_selected(self):
        chapter = self.selected_chapter.get()
        path = ROOT / f"CHAPTER {chapter}" / f"Ex-{chapter}.py"
        self.check_exercise_path(str(path))

    def check_exercise_path(self, selection):
        self.check_button.configure(state="disabled")
        self.update_idletasks()

        try:
            result = check_exercise(selection)
        except Exception as error:
            result = {
                "status": "Not checked",
                "path": None,
                "issues": [f"The checker encountered an unexpected problem: {error}"],
            }

        self.check_button.configure(state="normal")
        self.display_result(result)

    def display_result(self, result):
        status = result["status"]
        status_styles = {
            "Correct": ("Correct", "#1B7F5A"),
            "Not correct": ("Not correct", "#C83C3C"),
            "Not checked": ("Not checked", "#A66A00"),
        }
        label, color = status_styles[status]
        self.status_label.configure(text=label, foreground=color)

        lines = []
        if result["path"]:
            try:
                display_path = result["path"].relative_to(ROOT)
            except ValueError:
                display_path = result["path"]
            lines.append(f"Exercise: {display_path}\n")

        if status == "Correct":
            lines.append(result["issues"][0])
        else:
            lines.append("Follow these steps:")
            for number, issue in enumerate(result["issues"], 1):
                lines.append(f"\n{number}. {issue}")

        self.results.configure(state="normal")
        self.results.delete("1.0", "end")
        self.results.insert("1.0", "\n".join(lines))
        self.results.configure(state="disabled")


if __name__ == "__main__":
    app = ExerciseApp()
    app.mainloop()
